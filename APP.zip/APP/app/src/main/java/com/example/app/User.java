package com.example.app;

public class User {
    private String username;
    private String password;

    // Constructors, getters, and setters
}